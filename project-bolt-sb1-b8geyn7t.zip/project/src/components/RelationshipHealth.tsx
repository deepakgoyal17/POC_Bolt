import React from 'react';
import Card from './common/Card';
import StatusIndicator from './common/StatusIndicator';
import TrendIndicator from './common/TrendIndicator';
import { RelationshipHealth as HealthType } from '../types';

interface RelationshipHealthProps {
  metrics: HealthType[];
}

const RelationshipHealth: React.FC<RelationshipHealthProps> = ({ metrics }) => {
  const getOverallHealth = (): 'good' | 'warning' | 'risk' => {
    const avgScore = metrics.reduce((sum, metric) => sum + metric.score, 0) / metrics.length;
    if (avgScore >= 80) return 'good';
    if (avgScore >= 60) return 'warning';
    return 'risk';
  };

  const overallHealth = getOverallHealth();
  const overallScore = Math.round(metrics.reduce((sum, metric) => sum + metric.score, 0) / metrics.length);

  return (
    <Card title="Relationship Health">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <h3 className="font-semibold text-gray-900">Overall Health</h3>
            <StatusIndicator status={overallHealth} showText size="sm" />
          </div>
          <p className="text-sm text-gray-600">Based on 5 key metrics</p>
        </div>
        <div className="text-3xl font-bold text-blue-900">{overallScore}<span className="text-sm text-gray-500">/100</span></div>
      </div>

      <div className="divide-y divide-gray-100">
        {metrics.map((metric) => (
          <div key={metric.category} className="py-2.5 flex items-center justify-between">
            <div className="flex-grow">
              <div className="flex items-center gap-2">
                <StatusIndicator status={metric.status} size="sm" />
                <h4 className="font-medium text-gray-800">{metric.category}</h4>
                <TrendIndicator trend={metric.trend} />
              </div>
              <p className="text-xs text-gray-600 mt-0.5">{metric.details}</p>
            </div>
            <div className="text-xl font-bold text-blue-900 ml-4">{metric.score}</div>
          </div>
        ))}
      </div>
    </Card>
  );
};

export default RelationshipHealth;
import React, { ReactNode } from 'react';

interface CardProps {
  title?: string;
  children: ReactNode;
  className?: string;
  headerRight?: ReactNode;
  clickable?: boolean;
  onClick?: () => void;
  noPadding?: boolean;
}

const Card: React.FC<CardProps> = ({ 
  title, 
  children, 
  className = '',
  headerRight,
  clickable = false,
  onClick,
  noPadding = false
}) => {
  return (
    <div 
      className={`bg-white rounded-lg shadow-md overflow-hidden transition-all duration-300 
        ${clickable ? 'hover:shadow-lg cursor-pointer' : ''} ${className}`}
      onClick={clickable && onClick ? onClick : undefined}
    >
      {title && (
        <div className="flex justify-between items-center border-b border-gray-100 px-5 py-3">
          <h3 className="font-semibold text-gray-800">{title}</h3>
          {headerRight && (
            <div>{headerRight}</div>
          )}
        </div>
      )}
      <div className={noPadding ? '' : 'p-5'}>
        {children}
      </div>
    </div>
  );
};

export default Card;
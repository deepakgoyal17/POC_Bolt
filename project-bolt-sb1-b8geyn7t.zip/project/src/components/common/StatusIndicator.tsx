import React from 'react';

interface StatusIndicatorProps {
  status: 'good' | 'warning' | 'risk';
  showText?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

const StatusIndicator: React.FC<StatusIndicatorProps> = ({ 
  status, 
  showText = false,
  size = 'md' 
}) => {
  const getStatusColor = () => {
    switch (status) {
      case 'good':
        return 'bg-emerald-500';
      case 'warning':
        return 'bg-amber-500';
      case 'risk':
        return 'bg-red-500';
      default:
        return 'bg-gray-400';
    }
  };

  const getStatusText = () => {
    switch (status) {
      case 'good':
        return 'Good';
      case 'warning':
        return 'Attention';
      case 'risk':
        return 'At Risk';
      default:
        return 'Unknown';
    }
  };

  const getSizeClass = () => {
    switch (size) {
      case 'sm':
        return 'w-2 h-2';
      case 'lg':
        return 'w-4 h-4';
      case 'md':
      default:
        return 'w-3 h-3';
    }
  };

  return (
    <div className="flex items-center gap-2">
      <div className={`${getSizeClass()} ${getStatusColor()} rounded-full`}></div>
      {showText && (
        <span className="text-sm font-medium">{getStatusText()}</span>
      )}
    </div>
  );
};

export default StatusIndicator;
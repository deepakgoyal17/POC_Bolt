import React from 'react';
import { Bell, Search, Menu } from 'lucide-react';
import { Client } from '../../types';

interface HeaderProps {
  client: Client;
}

const Header: React.FC<HeaderProps> = ({ client }) => {
  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
      <div className="px-4 sm:px-6 lg:px-8 mx-auto">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <button className="p-2 rounded-md text-gray-500 lg:hidden">
              <Menu size={24} />
            </button>
            <div className="ml-2 lg:ml-0">
              <h1 className="text-xl font-semibold text-blue-900">Pre-Meeting Brief</h1>
            </div>
          </div>
          
          <div className="flex-1 max-w-md mx-4 hidden md:flex">
            <div className="w-full relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search size={18} className="text-gray-400" />
              </div>
              <input
                type="text"
                className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md 
                  leading-5 bg-gray-50 placeholder-gray-500 text-gray-900 
                  focus:outline-none focus:ring-1 focus:ring-blue-900 focus:border-blue-900 sm:text-sm"
                placeholder="Search clients or meetings..."
              />
            </div>
          </div>
          
          <div className="flex items-center">
            <button className="p-2 rounded-full text-gray-500 hover:text-gray-700 hover:bg-gray-100 relative">
              <Bell size={20} />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full"></span>
            </button>
            
            <div className="ml-4 flex items-center">
              <div className="flex-shrink-0 h-8 w-8">
                <img 
                  className="h-8 w-8 rounded-full object-cover" 
                  src="https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
                  alt="Profile" 
                />
              </div>
              <div className="ml-2 hidden md:flex flex-col">
                <span className="text-sm font-medium text-gray-800">David Wilson</span>
                <span className="text-xs text-gray-500">Relationship Manager</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
import React, { useState } from 'react';
import { Calendar, Phone, Mail, ChevronDown, ChevronUp, Users } from 'lucide-react';
import Card from './common/Card';
import { MeetingNote } from '../types';
import { formatDate } from '../utils/formatters';

interface MeetingNotesProps {
  notes: MeetingNote[];
}

const MeetingNotes: React.FC<MeetingNotesProps> = ({ notes }) => {
  const [expandedNoteId, setExpandedNoteId] = useState<string | null>(null);

  const getTypeIcon = (type: 'call' | 'meeting' | 'email') => {
    switch (type) {
      case 'call':
        return <Phone size={16} className="text-blue-600" />;
      case 'meeting':
        return <Users size={16} className="text-emerald-600" />;
      case 'email':
        return <Mail size={16} className="text-amber-600" />;
    }
  };

  const toggleExpand = (id: string) => {
    setExpandedNoteId(expandedNoteId === id ? null : id);
  };

  return (
    <Card 
      title="Recent Interactions" 
      className="h-full"
      headerRight={
        <span className="text-sm text-gray-500">Last 3 months</span>
      }
    >
      <div className="space-y-4">
        {notes.map((note) => (
          <div 
            key={note.id}
            className="border border-gray-100 rounded-lg overflow-hidden transition-all duration-300
              hover:shadow-md bg-white"
          >
            <div 
              className="flex items-center justify-between p-4 cursor-pointer"
              onClick={() => toggleExpand(note.id)}
            >
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-gray-50 rounded-lg">
                  {getTypeIcon(note.type)}
                </div>
                <div>
                  <h4 className="font-medium text-gray-900">{note.summary}</h4>
                  <div className="flex items-center text-sm text-gray-500 mt-1">
                    <Calendar size={14} className="mr-1" />
                    {formatDate(note.date)}
                  </div>
                </div>
              </div>
              {expandedNoteId === note.id ? (
                <ChevronUp size={20} className="text-gray-400" />
              ) : (
                <ChevronDown size={20} className="text-gray-400" />
              )}
            </div>

            {expandedNoteId === note.id && (
              <div className="px-4 pb-4 pt-2 border-t border-gray-100 bg-gray-50">
                <div className="space-y-3">
                  <div>
                    <h5 className="text-sm font-medium text-gray-700 mb-1">Key Points</h5>
                    <ul className="list-disc list-inside space-y-1">
                      {note.keyPoints.map((point, index) => (
                        <li key={index} className="text-sm text-gray-600">{point}</li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h5 className="text-sm font-medium text-gray-700 mb-1">Attendees</h5>
                    <div className="flex flex-wrap gap-2">
                      {note.attendees.map((attendee, index) => (
                        <span 
                          key={index}
                          className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs
                            font-medium bg-blue-50 text-blue-700"
                        >
                          {attendee}
                        </span>
                      ))}
                    </div>
                  </div>

                  {note.nextSteps && (
                    <div>
                      <h5 className="text-sm font-medium text-gray-700 mb-1">Next Steps</h5>
                      <ul className="list-disc list-inside space-y-1">
                        {note.nextSteps.map((step, index) => (
                          <li key={index} className="text-sm text-gray-600">{step}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </Card>
  );
};

export default MeetingNotes;
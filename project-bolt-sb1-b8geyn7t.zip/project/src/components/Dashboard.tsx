import React from 'react';
import ClientOverview from './ClientOverview';
import ExecutiveSummary from './ExecutiveSummary';
import RelationshipHealth from './RelationshipHealth';
import OpportunitySpotlight from './OpportunitySpotlight';
import TalkingPoints from './TalkingPoints';
import FollowUpCreator from './FollowUpCreator';
import MeetingNotes from './MeetingNotes';
import { 
  client, 
  relationshipHealth, 
  executiveSummary, 
  opportunities, 
  talkingPoints,
  followUpTasks,
  meetingNotes
} from '../utils/mockData';

const Dashboard: React.FC = () => {
  return (
    <div className="max-w-screen-2xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
      <div className="flex flex-col space-y-6">
        {/* Client Overview */}
        <ClientOverview client={client} />
        
        {/* Main 3-column grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 auto-rows-min">
          {/* Left Column */}
          <div className="space-y-6">
            <ExecutiveSummary points={executiveSummary} />
            <MeetingNotes notes={meetingNotes} />
          </div>
          
          {/* Middle Column */}
          <div className="space-y-6">
            <RelationshipHealth metrics={relationshipHealth} />
            <OpportunitySpotlight opportunities={opportunities} />
          </div>
          
          {/* Right Column */}
          <div className="space-y-6">
            <TalkingPoints points={talkingPoints} />
            <FollowUpCreator existingTasks={followUpTasks} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
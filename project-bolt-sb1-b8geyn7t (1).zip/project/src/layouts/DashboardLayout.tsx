import React, { ReactNode } from 'react';
import Header from '../components/common/Header';
import { client } from '../utils/mockData';

interface DashboardLayoutProps {
  children: ReactNode;
}

const DashboardLayout: React.FC<DashboardLayoutProps> = ({ children }) => {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header client={client} />
      <main className="flex-grow">
        {children}
      </main>
    </div>
  );
};

export default DashboardLayout;
import { 
  Client, 
  RelationshipHealth, 
  Opportunity, 
  ExecutiveSummaryPoint, 
  TalkingPoint,
  FollowUpTask,
  MeetingNote,
  ServiceRequest
} from '../types';

export const businessMetrics = {
  monthlyRevenue: [
    { month: 'Jan', revenue: 850000, previousYear: 720000 },
    { month: 'Feb', revenue: 920000, previousYear: 750000 },
    { month: 'Mar', revenue: 880000, previousYear: 780000 },
    { month: 'Apr', revenue: 950000, previousYear: 800000 },
    { month: 'May', revenue: 1020000, previousYear: 850000 },
    { month: 'Jun', revenue: 1100000, previousYear: 900000 }
  ],
  productMix: [
    { month: 'Jan', lending: 45, treasury: 35, trade: 20 },
    { month: 'Feb', lending: 42, treasury: 38, trade: 20 },
    { month: 'Mar', lending: 40, treasury: 40, trade: 20 },
    { month: 'Apr', lending: 38, treasury: 42, trade: 20 },
    { month: 'May', lending: 35, treasury: 45, trade: 20 },
    { month: 'Jun', lending: 35, treasury: 45, trade: 20 }
  ]
};

export const serviceRequests: ServiceRequest[] = [
  {
    id: '1',
    title: 'Digital Banking Access Issue',
    description: 'Unable to access specific treasury management features in the digital banking platform',
    status: 'in_progress',
    priority: 'high',
    createdAt: '2024-03-10T09:00:00Z',
    estimatedCompletion: '2024-03-12T17:00:00Z',
    assignedTo: 'Tech Support Team',
    category: 'Digital Banking',
    updates: [
      {
        date: '2024-03-10T09:30:00Z',
        message: 'Issue identified as permission configuration problem',
        author: 'Sarah Tech'
      },
      {
        date: '2024-03-11T14:00:00Z',
        message: 'Permission matrix being updated, testing in progress',
        author: 'Mike Support'
      }
    ]
  },
  {
    id: '2',
    title: 'Wire Transfer Template Setup',
    description: 'Request to create new wire transfer templates for recurring international payments',
    status: 'pending',
    priority: 'medium',
    createdAt: '2024-03-09T15:00:00Z',
    estimatedCompletion: '2024-03-13T17:00:00Z',
    assignedTo: 'Treasury Services',
    category: 'Payments'
  },
  {
    id: '3',
    title: 'Trade Finance Documentation',
    description: 'Need assistance with letter of credit documentation for new export transaction',
    status: 'resolved',
    priority: 'high',
    createdAt: '2024-03-05T10:00:00Z',
    estimatedCompletion: '2024-03-08T17:00:00Z',
    assignedTo: 'Trade Finance Team',
    category: 'Trade Finance',
    updates: [
      {
        date: '2024-03-06T11:00:00Z',
        message: 'Documentation reviewed and approved',
        author: 'John Trade'
      },
      {
        date: '2024-03-07T16:00:00Z',
        message: 'Final documents sent to client',
        author: 'John Trade'
      }
    ]
  },
  {
    id: '4',
    title: 'Account Statement Discrepancy',
    description: 'Reconciliation issue found in February account statement',
    status: 'blocked',
    priority: 'medium',
    createdAt: '2024-03-08T13:00:00Z',
    estimatedCompletion: '2024-03-14T17:00:00Z',
    assignedTo: 'Account Services',
    category: 'Accounting',
    updates: [
      {
        date: '2024-03-09T10:00:00Z',
        message: 'Awaiting additional transaction details from client',
        author: 'Emma Account'
      }
    ]
  }
];

export const client: Client = {
  id: '1',
  name: 'Margaret Chen',
  companyName: 'Apex Manufacturing',
  industry: 'Industrial Manufacturing',
  annualRevenue: 78500000,
  totalAssets: 120000000,
  relationshipSince: '2017-05-12',
  lastContactDate: '2023-11-15',
  profileImage: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
};

export const relationshipHealth: RelationshipHealth[] = [
  {
    category: 'Deposit Balance',
    status: 'good',
    score: 92,
    trend: 'up',
    details: 'Average balance increased 13% YoY'
  },
  {
    category: 'Loan Performance',
    status: 'good',
    score: 95,
    trend: 'stable',
    details: 'No late payments in last 24 months'
  },
  {
    category: 'Product Utilization',
    status: 'warning',
    score: 68,
    trend: 'stable',
    details: 'Only using 4 of 7 recommended products'
  },
  {
    category: 'Digital Engagement',
    status: 'risk',
    score: 42,
    trend: 'down',
    details: 'Low portal usage, decreased 15% last quarter'
  },
  {
    category: 'Relationship Depth',
    status: 'good',
    score: 88,
    trend: 'up',
    details: 'Primary provider for 75% of banking services'
  }
];

export const opportunities: Opportunity[] = [
  {
    id: '1',
    title: 'Treasury Management Suite',
    description: 'Upgrade to premium Treasury Management services to increase efficiency and reduce manual processes.',
    estimatedRevenue: 85000,
    probability: 75,
    productCategory: 'Cash Management'
  },
  {
    id: '2',
    title: 'Equipment Financing',
    description: 'Opportunity to finance planned factory expansion with competitive rates and flexible terms.',
    estimatedRevenue: 250000,
    probability: 60,
    productCategory: 'Commercial Lending'
  }
];

export const executiveSummary: ExecutiveSummaryPoint[] = [
  {
    id: '1',
    title: 'Term Loan Renewal',
    description: 'Current $3.5M facility matures in 60 days. Pre-approval for renewal in process.',
    priority: 'high'
  },
  {
    id: '2',
    title: 'Treasury Management Opportunity',
    description: 'Current manual processes costing est. $120K annually. Our solution reduces by 70%.',
    priority: 'high'
  },
  {
    id: '3',
    title: 'Deposit Relationship Growth',
    description: 'Deposits increased 13% YoY with opportunity to optimize yield structure.',
    priority: 'medium'
  },
  {
    id: '4',
    title: 'Digital Portal Adoption',
    description: 'Low usage of digital banking platform requires training intervention.',
    priority: 'medium'
  }
];

export const talkingPoints: TalkingPoint[] = [
  {
    id: '1',
    category: 'Industry Insights',
    point: 'How are recent supply chain improvements affecting your production timelines?'
  },
  {
    id: '2',
    category: 'Future Plans',
    point: 'You mentioned potential European market expansion last quarter. Has the timeline changed?'
  },
  {
    id: '3',
    category: 'Treasury Management',
    point: 'What are the biggest pain points in your current cash management process?',
    relatedTo: 'Treasury Management Suite'
  },
  {
    id: '4',
    category: 'Risk Management',
    point: 'How are you managing FX risk with your growing international supplier base?'
  },
  {
    id: '5',
    category: 'Term Loan',
    point: 'Let\'s discuss options for your upcoming loan renewal. Are your capital needs changing?',
    relatedTo: 'Term Loan Renewal'
  }
];

export const followUpTasks: FollowUpTask[] = [
  {
    id: '1',
    title: 'Send Treasury Management Proposal',
    description: 'Prepare and deliver formal proposal for Treasury Management upgrade.',
    dueDate: '2023-11-28',
    priority: 'high',
    completed: false,
    assignedTo: 'currentUser'
  },
  {
    id: '2',
    title: 'Schedule Digital Portal Training',
    description: 'Coordinate with Digital Banking team for customer training session.',
    dueDate: '2023-12-05',
    priority: 'medium',
    completed: false,
    assignedTo: 'currentUser'
  }
];

export const meetingNotes: MeetingNote[] = [
  {
    id: '1',
    date: '2024-02-15',
    type: 'meeting',
    summary: 'Quarterly Business Review',
    keyPoints: [
      'Discussed Q4 2023 performance - revenue up 15% YoY',
      'Reviewed expansion plans for new production facility',
      'Identified need for additional working capital line',
      'Digital banking adoption remains a challenge'
    ],
    attendees: ['Margaret Chen', 'David Wilson', 'John Smith (CFO)'],
    nextSteps: [
      'Prepare working capital facility proposal',
      'Schedule digital banking training session',
      'Follow up on equipment financing options'
    ]
  },
  {
    id: '2',
    date: '2024-01-20',
    type: 'call',
    summary: 'Treasury Management Discussion',
    keyPoints: [
      'Reviewed current cash management processes',
      'Identified manual reconciliation pain points',
      'Discussed automated solutions and potential cost savings',
      'Client expressed interest in premium TM suite'
    ],
    attendees: ['Margaret Chen', 'David Wilson', 'Sarah Lee (Treasury)'],
    nextSteps: [
      'Send detailed TM proposal',
      'Schedule demo of new platform features'
    ]
  },
  {
    id: '3',
    date: '2023-12-05',
    type: 'meeting',
    summary: 'Annual Planning Session',
    keyPoints: [
      'Reviewed 2024 growth projections',
      'Discussed international expansion strategy',
      'Evaluated current banking product suite utilization',
      'Identified potential areas for relationship expansion'
    ],
    attendees: ['Margaret Chen', 'David Wilson', 'Full Executive Team'],
    nextSteps: [
      'Update relationship plan for 2024',
      'Research international banking solutions',
      'Schedule follow-up on product opportunities'
    ]
  }
];
import React, { useState } from 'react';
import { Check, Plus, Calendar, Clock, User } from 'lucide-react';
import Card from './common/Card';
import { FollowUpTask } from '../types';

interface FollowUpCreatorProps {
  existingTasks: FollowUpTask[];
}

const FollowUpCreator: React.FC<FollowUpCreatorProps> = ({ existingTasks }) => {
  const [tasks, setTasks] = useState<FollowUpTask[]>(existingTasks);
  const [isCreating, setIsCreating] = useState(false);
  const [newTask, setNewTask] = useState<Partial<FollowUpTask>>({
    title: '',
    description: '',
    dueDate: '',
    priority: 'medium',
    completed: false,
    assignedTo: 'currentUser'
  });

  const handleToggleComplete = (id: string) => {
    setTasks(tasks.map(task => 
      task.id === id ? { ...task, completed: !task.completed } : task
    ));
  };

  const handleCreateTask = () => {
    if (!newTask.title) return;
    
    const task: FollowUpTask = {
      id: Date.now().toString(),
      title: newTask.title || '',
      description: newTask.description || '',
      dueDate: newTask.dueDate || new Date().toISOString().split('T')[0],
      priority: newTask.priority as 'high' | 'medium' | 'low',
      completed: false,
      assignedTo: newTask.assignedTo || 'currentUser'
    };
    
    setTasks([...tasks, task]);
    setNewTask({
      title: '',
      description: '',
      dueDate: '',
      priority: 'medium',
      completed: false,
      assignedTo: 'currentUser'
    });
    setIsCreating(false);
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'bg-red-50 text-red-700 border-red-200';
      case 'medium':
        return 'bg-amber-50 text-amber-700 border-amber-200';
      case 'low':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      default:
        return 'bg-gray-50 text-gray-700 border-gray-200';
    }
  };

  return (
    <Card 
      title="Follow-Up Tasks" 
      className="h-full"
      headerRight={
        !isCreating && (
          <button 
            className="flex items-center text-sm font-medium text-blue-600 hover:text-blue-800"
            onClick={() => setIsCreating(true)}
          >
            <Plus size={16} className="mr-1" />
            New Task
          </button>
        )
      }
    >
      {isCreating ? (
        <div className="bg-blue-50 border border-blue-100 rounded-lg p-4 mb-4">
          <h4 className="font-medium text-blue-900 mb-3">Create New Follow-Up</h4>
          
          <div className="space-y-3">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Task Title
              </label>
              <input
                type="text"
                value={newTask.title}
                onChange={(e) => setNewTask({...newTask, title: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm 
                  focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                placeholder="Enter task title"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Description
              </label>
              <textarea
                value={newTask.description}
                onChange={(e) => setNewTask({...newTask, description: e.target.value})}
                rows={2}
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm 
                  focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                placeholder="Enter task description"
              ></textarea>
            </div>
            
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Due Date
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Calendar size={16} className="text-gray-400" />
                  </div>
                  <input
                    type="date"
                    value={newTask.dueDate}
                    onChange={(e) => setNewTask({...newTask, dueDate: e.target.value})}
                    className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm 
                      focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Priority
                </label>
                <select
                  value={newTask.priority}
                  onChange={(e) => setNewTask({...newTask, priority: e.target.value as 'high' | 'medium' | 'low'})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm 
                    focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="high">High</option>
                  <option value="medium">Medium</option>
                  <option value="low">Low</option>
                </select>
              </div>
            </div>
            
            <div className="flex justify-end gap-2 pt-2">
              <button 
                className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium 
                  text-gray-700 bg-white hover:bg-gray-50"
                onClick={() => setIsCreating(false)}
              >
                Cancel
              </button>
              <button 
                className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm 
                  font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none 
                  focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                onClick={handleCreateTask}
              >
                Create Task
              </button>
            </div>
          </div>
        </div>
      ) : null}
      
      <div className="space-y-3">
        {tasks.length === 0 && !isCreating ? (
          <div className="text-center py-6">
            <p className="text-gray-500">No follow-up tasks created yet</p>
            <button 
              className="mt-2 text-blue-600 font-medium hover:text-blue-800"
              onClick={() => setIsCreating(true)}
            >
              Create your first task
            </button>
          </div>
        ) : (
          tasks.map((task) => (
            <div 
              key={task.id} 
              className={`flex items-start p-3 border rounded-lg transition-all duration-300
                ${task.completed 
                  ? 'border-gray-200 bg-gray-50' 
                  : 'border-gray-200 bg-white hover:shadow-sm'
                }`}
            >
              <button 
                className={`flex-shrink-0 w-5 h-5 rounded-full border flex items-center 
                  justify-center mr-3 mt-0.5 transition-colors duration-200
                  ${task.completed 
                    ? 'bg-green-500 border-green-500 text-white' 
                    : 'border-gray-300 hover:border-blue-500'
                  }`}
                onClick={() => handleToggleComplete(task.id)}
              >
                {task.completed && <Check size={12} />}
              </button>
              
              <div className="flex-grow">
                <div className="flex justify-between items-start">
                  <h4 className={`font-medium ${task.completed ? 'text-gray-500 line-through' : 'text-gray-900'}`}>
                    {task.title}
                  </h4>
                  <span className={`text-xs px-2 py-0.5 rounded-full border ml-2 ${getPriorityColor(task.priority)}`}>
                    {task.priority}
                  </span>
                </div>
                
                {task.description && (
                  <p className={`text-sm mt-1 ${task.completed ? 'text-gray-400' : 'text-gray-700'}`}>
                    {task.description}
                  </p>
                )}
                
                <div className="flex items-center gap-4 mt-2">
                  <div className="flex items-center text-xs text-gray-500">
                    <Calendar size={14} className="mr-1" />
                    {new Date(task.dueDate).toLocaleDateString('en-US', { 
                      month: 'short', 
                      day: 'numeric'
                    })}
                  </div>
                  
                  <div className="flex items-center text-xs text-gray-500">
                    <User size={14} className="mr-1" />
                    You
                  </div>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </Card>
  );
};

export default FollowUpCreator;
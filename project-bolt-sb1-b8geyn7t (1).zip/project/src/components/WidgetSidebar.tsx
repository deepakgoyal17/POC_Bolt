import React from 'react';
import { LayoutDashboard, TrendingUp, Lightbulb, MessageSquare, CheckSquare, FileText, BarChart, HeadphonesIcon } from 'lucide-react';

interface WidgetSidebarProps {
  onAddWidget: (widgetType: string) => void;
}

const WidgetSidebar: React.FC<WidgetSidebarProps> = ({ onAddWidget }) => {
  const widgets = [
    { type: 'ExecutiveSummary', icon: LayoutDashboard, label: 'Executive Summary' },
    { type: 'RelationshipHealth', icon: TrendingUp, label: 'Relationship Health' },
    { type: 'OpportunitySpotlight', icon: Lightbulb, label: 'Opportunities' },
    { type: 'TalkingPoints', icon: MessageSquare, label: 'Talking Points' },
    { type: 'FollowUpCreator', icon: CheckSquare, label: 'Follow-Up Tasks' },
    { type: 'MeetingNotes', icon: FileText, label: 'Meeting Notes' },
    { type: 'BusinessMetrics', icon: BarChart, label: 'Business Metrics' },
    { type: 'ServiceRequests', icon: HeadphonesIcon, label: 'Service Requests' }
  ];

  return (
    <div className="w-64 bg-white border-r border-gray-200 p-4">
      <h2 className="text-lg font-semibold text-gray-900 mb-4">Widgets</h2>
      <div className="space-y-2">
        {widgets.map((widget) => {
          const Icon = widget.icon;
          return (
            <button
              key={widget.type}
              className="w-full flex items-center gap-2 p-3 text-left text-gray-700 hover:bg-gray-50 
                rounded-lg transition-colors duration-200"
              onClick={() => onAddWidget(widget.type)}
              draggable
            >
              <Icon size={18} className="text-gray-500" />
              <span>{widget.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default WidgetSidebar;
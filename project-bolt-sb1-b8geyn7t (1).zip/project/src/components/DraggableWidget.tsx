import React from 'react';
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { X, GripVertical } from 'lucide-react';
import ExecutiveSummary from './ExecutiveSummary';
import RelationshipHealth from './RelationshipHealth';
import OpportunitySpotlight from './OpportunitySpotlight';
import TalkingPoints from './TalkingPoints';
import FollowUpCreator from './FollowUpCreator';
import MeetingNotes from './MeetingNotes';
import BusinessMetrics from './widgets/BusinessMetrics';
import ServiceRequests from './widgets/ServiceRequests';
import { businessMetrics, serviceRequests } from '../utils/mockData';

interface DraggableWidgetProps {
  id: string;
  type: string;
  data: any;
  onRemove: () => void;
  isDragging?: boolean;
}

const DraggableWidget: React.FC<DraggableWidgetProps> = ({ 
  id, 
  type, 
  data, 
  onRemove,
  isDragging = false
}) => {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging: isSortableDragging
  } = useSortable({ id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
    cursor: 'grab'
  };

  const renderWidget = () => {
    switch (type) {
      case 'ExecutiveSummary':
        return <ExecutiveSummary points={data} />;
      case 'RelationshipHealth':
        return <RelationshipHealth metrics={data} />;
      case 'OpportunitySpotlight':
        return <OpportunitySpotlight opportunities={data} />;
      case 'TalkingPoints':
        return <TalkingPoints points={data} />;
      case 'FollowUpCreator':
        return <FollowUpCreator existingTasks={data} />;
      case 'MeetingNotes':
        return <MeetingNotes notes={data} />;
      case 'BusinessMetrics':
        return <BusinessMetrics data={businessMetrics} />;
      case 'ServiceRequests':
        return <ServiceRequests requests={serviceRequests} />;
      default:
        return null;
    }
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={`group relative flex flex-col h-fit max-h-[600px] overflow-hidden
        transition-shadow duration-200 ${isSortableDragging ? 'shadow-2xl scale-105' : ''}`}
    >
      <div 
        className="absolute top-0 right-0 z-10 flex items-center gap-2 p-2 opacity-0 
          group-hover:opacity-100 transition-opacity duration-200 bg-white/80 rounded-bl-lg"
      >
        <button
          className="p-1.5 rounded-md bg-gray-100 hover:bg-gray-200 text-gray-600 
            hover:text-gray-800 transition-colors duration-200 cursor-grab"
          {...listeners}
          {...attributes}
        >
          <GripVertical size={16} />
        </button>
        <button
          onClick={onRemove}
          className="p-1.5 rounded-md bg-gray-100 hover:bg-red-100 text-gray-600 
            hover:text-red-600 transition-colors duration-200"
        >
          <X size={16} />
        </button>
      </div>
      <div className="overflow-auto">
        {renderWidget()}
      </div>
    </div>
  );
};

export default DraggableWidget;
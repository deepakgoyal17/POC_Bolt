import React, { useState } from 'react';
import { DndContext, DragEndEvent, DragStartEvent, DragOverlay, useSensor, useSensors, PointerSensor } from '@dnd-kit/core';
import { SortableContext, rectSortingStrategy } from '@dnd-kit/sortable';
import ClientOverview from './ClientOverview';
import WidgetSidebar from './WidgetSidebar';
import DraggableWidget from './DraggableWidget';
import { 
  client, 
  relationshipHealth, 
  executiveSummary, 
  opportunities, 
  talkingPoints, 
  followUpTasks, 
  meetingNotes,
  businessMetrics 
} from '../utils/mockData';

const Dashboard: React.FC = () => {
  const [widgets, setWidgets] = useState([
    { id: 'executive-summary', type: 'ExecutiveSummary', data: executiveSummary },
    { id: 'relationship-health', type: 'RelationshipHealth', data: relationshipHealth },
    { id: 'opportunity-spotlight', type: 'OpportunitySpotlight', data: opportunities },
    { id: 'talking-points', type: 'TalkingPoints', data: talkingPoints },
    { id: 'follow-up', type: 'FollowUpCreator', data: followUpTasks },
    { id: 'meeting-notes', type: 'MeetingNotes', data: meetingNotes }
  ]);

  const [activeId, setActiveId] = useState<string | null>(null);

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    })
  );

  const handleDragStart = (event: DragStartEvent) => {
    setActiveId(event.active.id as string);
  };

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    
    if (over && active.id !== over.id) {
      setWidgets((items) => {
        const oldIndex = items.findIndex((i) => i.id === active.id);
        const newIndex = items.findIndex((i) => i.id === over.id);
        
        const newItems = [...items];
        const [movedItem] = newItems.splice(oldIndex, 1);
        newItems.splice(newIndex, 0, movedItem);
        
        return newItems;
      });
    }
    
    setActiveId(null);
  };

  const addWidget = (widgetType: string) => {
    const newWidget = {
      id: `${widgetType}-${Date.now()}`,
      type: widgetType,
      data: getWidgetData(widgetType)
    };
    setWidgets([...widgets, newWidget]);
  };

  const removeWidget = (widgetId: string) => {
    setWidgets(widgets.filter(widget => widget.id !== widgetId));
  };

  const getWidgetData = (type: string) => {
    switch (type) {
      case 'ExecutiveSummary':
        return executiveSummary;
      case 'RelationshipHealth':
        return relationshipHealth;
      case 'OpportunitySpotlight':
        return opportunities;
      case 'TalkingPoints':
        return talkingPoints;
      case 'FollowUpCreator':
        return followUpTasks;
      case 'MeetingNotes':
        return meetingNotes;
      case 'BusinessMetrics':
        return businessMetrics;
      default:
        return null;
    }
  };

  return (
    <div className="flex h-[calc(100vh-4rem)]">
      <WidgetSidebar onAddWidget={addWidget} />
      <div className="flex-1 overflow-auto p-6">
        <ClientOverview client={client} />
        <DndContext 
          sensors={sensors}
          onDragStart={handleDragStart}
          onDragEnd={handleDragEnd}
        >
          <div className="mt-6 grid grid-cols-1 lg:grid-cols-3 gap-6 min-h-[calc(100vh-16rem)]">
            <SortableContext 
              items={widgets.map(w => w.id)}
              strategy={rectSortingStrategy}
            >
              {widgets.map((widget) => (
                <DraggableWidget
                  key={widget.id}
                  id={widget.id}
                  type={widget.type}
                  data={widget.data}
                  onRemove={() => removeWidget(widget.id)}
                  isDragging={activeId === widget.id}
                />
              ))}
            </SortableContext>
          </div>
        </DndContext>
      </div>
    </div>
  );
};

export default Dashboard;
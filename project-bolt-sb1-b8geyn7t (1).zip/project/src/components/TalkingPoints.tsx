import React, { useState } from 'react';
import { MessageSquare, RefreshCw, ThumbsUp, ThumbsDown } from 'lucide-react';
import Card from './common/Card';
import { TalkingPoint } from '../types';

interface TalkingPointsProps {
  points: TalkingPoint[];
}

const TalkingPoints: React.FC<TalkingPointsProps> = ({ points }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  
  const categories = ['All', ...new Set(points.map(point => point.category))];
  
  const filteredPoints = selectedCategory === 'All' 
    ? points 
    : points.filter(point => point.category === selectedCategory);
  
  return (
    <Card 
      title="Talking Points" 
      className="h-full"
      headerRight={
        <button className="flex items-center text-sm text-blue-600 hover:text-blue-800">
          <RefreshCw size={14} className="mr-1" />
          Refresh
        </button>
      }
    >
      <div className="mb-4 flex flex-wrap gap-2">
        {categories.map((category) => (
          <button
            key={category}
            className={`px-3 py-1 text-sm rounded-full transition-colors duration-200
              ${selectedCategory === category 
                ? 'bg-blue-100 text-blue-800 font-medium' 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            onClick={() => setSelectedCategory(category)}
          >
            {category}
          </button>
        ))}
      </div>
      
      <div className="space-y-3">
        {filteredPoints.map((point) => (
          <div 
            key={point.id} 
            className="bg-white border border-gray-100 rounded-lg p-4 shadow-sm 
              transition-all duration-300 hover:shadow-md"
          >
            <div className="flex items-start">
              <div className="flex-shrink-0 p-1.5 bg-blue-50 rounded-lg mr-3">
                <MessageSquare size={18} className="text-blue-600" />
              </div>
              <div className="flex-grow">
                <div className="flex justify-between items-start">
                  <h4 className="font-medium text-gray-900">{point.category}</h4>
                  {point.relatedTo && (
                    <span className="text-xs bg-blue-50 text-blue-600 px-2 py-0.5 rounded-full">
                      {point.relatedTo}
                    </span>
                  )}
                </div>
                <p className="text-gray-700 mt-1">{point.point}</p>
              </div>
            </div>
            
            <div className="flex justify-end gap-2 mt-3">
              <button className="p-1.5 text-gray-400 hover:text-green-500 transition-colors duration-200">
                <ThumbsUp size={16} />
              </button>
              <button className="p-1.5 text-gray-400 hover:text-red-500 transition-colors duration-200">
                <ThumbsDown size={16} />
              </button>
            </div>
          </div>
        ))}
        
        <div className="mt-2 pt-2 border-t border-gray-100">
          <button className="w-full flex items-center justify-center py-2 text-sm
            text-blue-600 font-medium hover:text-blue-800 transition-colors duration-200">
            Generate More Talking Points
          </button>
        </div>
      </div>
    </Card>
  );
};

export default TalkingPoints;
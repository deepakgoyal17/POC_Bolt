import React from 'react';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';

interface TrendIndicatorProps {
  trend: 'up' | 'down' | 'stable';
  className?: string;
}

const TrendIndicator: React.FC<TrendIndicatorProps> = ({ trend, className = '' }) => {
  const getIcon = () => {
    switch (trend) {
      case 'up':
        return <TrendingUp size={16} className="text-emerald-500" />;
      case 'down':
        return <TrendingDown size={16} className="text-red-500" />;
      case 'stable':
        return <Minus size={16} className="text-gray-500" />;
      default:
        return null;
    }
  };

  return (
    <div className={`flex items-center ${className}`}>
      {getIcon()}
    </div>
  );
};

export default TrendIndicator;
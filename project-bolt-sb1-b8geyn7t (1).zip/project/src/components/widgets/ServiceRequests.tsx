import React, { useState } from 'react';
import { Clock, AlertCircle, CheckCircle2, XCircle, ChevronDown, ChevronUp } from 'lucide-react';
import Card from '../common/Card';
import { ServiceRequest } from '../../types';

interface ServiceRequestsProps {
  requests: ServiceRequest[];
}

const ServiceRequests: React.FC<ServiceRequestsProps> = ({ requests }) => {
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending':
        return <Clock size={16} className="text-amber-500" />;
      case 'in_progress':
        return <AlertCircle size={16} className="text-blue-500" />;
      case 'resolved':
        return <CheckCircle2 size={16} className="text-emerald-500" />;
      case 'blocked':
        return <XCircle size={16} className="text-red-500" />;
      default:
        return null;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'pending':
        return 'Pending';
      case 'in_progress':
        return 'In Progress';
      case 'resolved':
        return 'Resolved';
      case 'blocked':
        return 'Blocked';
      default:
        return status;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-amber-50 text-amber-700 border-amber-200';
      case 'in_progress':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'resolved':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'blocked':
        return 'bg-red-50 text-red-700 border-red-200';
      default:
        return 'bg-gray-50 text-gray-700 border-gray-200';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'bg-red-50 text-red-700 border-red-200';
      case 'medium':
        return 'bg-amber-50 text-amber-700 border-amber-200';
      case 'low':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      default:
        return 'bg-gray-50 text-gray-700 border-gray-200';
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const calculateTimeRemaining = (estimatedCompletion: string) => {
    const now = new Date();
    const completion = new Date(estimatedCompletion);
    const diff = completion.getTime() - now.getTime();
    
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    
    if (days > 0) {
      return `${days}d ${hours}h remaining`;
    }
    return `${hours}h remaining`;
  };

  return (
    <Card title="Service Requests">
      <div className="space-y-4">
        {requests.map((request) => (
          <div
            key={request.id}
            className="border border-gray-200 rounded-lg overflow-hidden bg-white transition-all duration-200 hover:shadow-md"
          >
            <div className="p-4">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-grow">
                  <div className="flex items-center gap-2 mb-2">
                    <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${getStatusColor(request.status)}`}>
                      <div className="flex items-center gap-1">
                        {getStatusIcon(request.status)}
                        {getStatusText(request.status)}
                      </div>
                    </span>
                    <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${getPriorityColor(request.priority)}`}>
                      {request.priority.charAt(0).toUpperCase() + request.priority.slice(1)}
                    </span>
                  </div>
                  
                  <h4 className="font-medium text-gray-900">{request.title}</h4>
                  <p className="text-sm text-gray-600 mt-1">{request.description}</p>
                  
                  <div className="flex flex-wrap gap-4 mt-3 text-sm text-gray-500">
                    <div>
                      <span className="font-medium">Created:</span> {formatDate(request.createdAt)}
                    </div>
                    <div>
                      <span className="font-medium">Category:</span> {request.category}
                    </div>
                    <div>
                      <span className="font-medium">Assigned:</span> {request.assignedTo}
                    </div>
                  </div>
                  
                  {request.estimatedCompletion && request.status !== 'resolved' && (
                    <div className="mt-2 text-sm">
                      <span className="font-medium text-blue-600">
                        {calculateTimeRemaining(request.estimatedCompletion)}
                      </span>
                    </div>
                  )}
                </div>
                
                {request.updates && request.updates.length > 0 && (
                  <button
                    onClick={() => setExpandedId(expandedId === request.id ? null : request.id)}
                    className="flex items-center justify-center p-1 rounded-md hover:bg-gray-100"
                  >
                    {expandedId === request.id ? (
                      <ChevronUp size={20} className="text-gray-500" />
                    ) : (
                      <ChevronDown size={20} className="text-gray-500" />
                    )}
                  </button>
                )}
              </div>
            </div>

            {expandedId === request.id && request.updates && (
              <div className="border-t border-gray-100 bg-gray-50 p-4">
                <h5 className="text-sm font-medium text-gray-700 mb-3">Updates</h5>
                <div className="space-y-3">
                  {request.updates.map((update, index) => (
                    <div key={index} className="flex gap-3">
                      <div className="flex-shrink-0 w-1 bg-blue-200 rounded"></div>
                      <div>
                        <p className="text-sm text-gray-600">{update.message}</p>
                        <div className="flex gap-2 mt-1 text-xs text-gray-500">
                          <span>{update.author}</span>
                          <span>·</span>
                          <span>{formatDate(update.date)}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </Card>
  );
};

export default ServiceRequests;
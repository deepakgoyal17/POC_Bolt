import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, AreaChart, Area } from 'recharts';
import Card from '../common/Card';
import { formatCurrency } from '../../utils/formatters';

interface BusinessMetricsProps {
  data: {
    monthlyRevenue: Array<{
      month: string;
      revenue: number;
      previousYear: number;
    }>;
    productMix: Array<{
      month: string;
      lending: number;
      treasury: number;
      trade: number;
    }>;
  };
}

const BusinessMetrics: React.FC<BusinessMetricsProps> = ({ data }) => {
  const formatYAxis = (value: number) => {
    return formatCurrency(value).replace('$', '');
  };

  return (
    <Card title="Business Performance">
      <div className="space-y-8">
        <div>
          <h4 className="font-medium text-gray-900 mb-4">Monthly Revenue</h4>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data.monthlyRevenue}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="month" />
                <YAxis tickFormatter={formatYAxis} />
                <Tooltip
                  formatter={(value: number) => formatCurrency(value)}
                  labelFormatter={(label) => `Month: ${label}`}
                />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="revenue"
                  name="Current Year"
                  stroke="#2563eb"
                  strokeWidth={2}
                  dot={{ r: 4 }}
                  activeDot={{ r: 6 }}
                />
                <Line
                  type="monotone"
                  dataKey="previousYear"
                  name="Previous Year"
                  stroke="#94a3b8"
                  strokeWidth={2}
                  dot={{ r: 4 }}
                  strokeDasharray="5 5"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div>
          <h4 className="font-medium text-gray-900 mb-4">Product Mix Distribution</h4>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data.productMix}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="month" />
                <YAxis tickFormatter={(value) => `${value}%`} />
                <Tooltip
                  formatter={(value: number) => `${value}%`}
                  labelFormatter={(label) => `Month: ${label}`}
                />
                <Legend />
                <Area
                  type="monotone"
                  dataKey="lending"
                  name="Lending"
                  stackId="1"
                  stroke="#2563eb"
                  fill="#2563eb"
                  fillOpacity={0.6}
                />
                <Area
                  type="monotone"
                  dataKey="treasury"
                  name="Treasury"
                  stackId="1"
                  stroke="#16a34a"
                  fill="#16a34a"
                  fillOpacity={0.6}
                />
                <Area
                  type="monotone"
                  dataKey="trade"
                  name="Trade Finance"
                  stackId="1"
                  stroke="#ca8a04"
                  fill="#ca8a04"
                  fillOpacity={0.6}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </Card>
  );
};

export default BusinessMetrics;
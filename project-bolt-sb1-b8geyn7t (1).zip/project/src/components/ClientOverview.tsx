import React from 'react';
import { Calendar, Phone, Building, DollarSign, Clock } from 'lucide-react';
import Card from './common/Card';
import { Client } from '../types';
import { formatCurrency, formatDate } from '../utils/formatters';

interface ClientOverviewProps {
  client: Client;
}

const ClientOverview: React.FC<ClientOverviewProps> = ({ client }) => {
  const calculateYears = (dateString: string): number => {
    const start = new Date(dateString);
    const now = new Date();
    return new Date(now.getTime() - start.getTime()).getFullYear() - 1970;
  };

  const relationshipYears = calculateYears(client.relationshipSince);

  return (
    <Card className="flex flex-col md:flex-row md:items-center gap-5">
      <div className="flex-shrink-0">
        <img 
          src={client.profileImage}
          alt={client.name}
          className="w-20 h-20 md:w-24 md:h-24 rounded-full object-cover border-4 border-white shadow"
        />
      </div>
      
      <div className="flex-grow">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-1">{client.companyName}</h2>
            <p className="text-blue-900 font-medium mb-2">{client.name} · Primary Contact</p>
          </div>
          
          <div className="flex flex-wrap gap-2 mt-2 md:mt-0">
            <button className="btn-primary">
              <Phone size={16} className="mr-1" />
              Call
            </button>
            <button className="btn-secondary">
              <Calendar size={16} className="mr-1" />
              Schedule
            </button>
          </div>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-4">
          <div className="flex items-center">
            <Building size={18} className="text-gray-500 mr-2" />
            <div>
              <p className="text-sm text-gray-500">Industry</p>
              <p className="font-medium">{client.industry}</p>
            </div>
          </div>
          
          <div className="flex items-center">
            <DollarSign size={18} className="text-gray-500 mr-2" />
            <div>
              <p className="text-sm text-gray-500">Annual Revenue</p>
              <p className="font-medium">{formatCurrency(client.annualRevenue)}</p>
            </div>
          </div>
          
          <div className="flex items-center">
            <Clock size={18} className="text-gray-500 mr-2" />
            <div>
              <p className="text-sm text-gray-500">Relationship</p>
              <p className="font-medium">{relationshipYears} Years ({formatDate(client.relationshipSince)})</p>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
};

export default ClientOverview;
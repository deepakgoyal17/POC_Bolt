import React from 'react';
import Card from './common/Card';
import { ExecutiveSummaryPoint } from '../types';

interface ExecutiveSummaryProps {
  points: ExecutiveSummaryPoint[];
}

const ExecutiveSummary: React.FC<ExecutiveSummaryProps> = ({ points }) => {
  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'bg-red-50 text-red-700 border-red-200';
      case 'medium':
        return 'bg-amber-50 text-amber-700 border-amber-200';
      case 'low':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      default:
        return 'bg-gray-50 text-gray-700 border-gray-200';
    }
  };

  const getPriorityLabel = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'Priority';
      case 'medium':
        return 'Important';
      case 'low':
        return 'Note';
      default:
        return 'Info';
    }
  };

  return (
    <Card 
      title="Executive Summary" 
      headerRight={
        <span className="text-sm text-gray-500">
          Last updated: {new Date().toLocaleDateString()}
        </span>
      }
    >
      <div className="space-y-3">
        {points.map((point) => (
          <div 
            key={point.id} 
            className="bg-white border border-gray-100 rounded-lg p-3 
              transition-all duration-300 hover:shadow-sm"
          >
            <div className="flex justify-between items-start gap-2">
              <h4 className="font-medium text-gray-900">{point.title}</h4>
              <span 
                className={`text-xs px-2 py-0.5 rounded-full border flex-shrink-0 ${getPriorityColor(point.priority)}`}
              >
                {getPriorityLabel(point.priority)}
              </span>
            </div>
            <p className="text-sm text-gray-700 mt-1.5">{point.description}</p>
          </div>
        ))}
      </div>
    </Card>
  );
};

export default ExecutiveSummary;
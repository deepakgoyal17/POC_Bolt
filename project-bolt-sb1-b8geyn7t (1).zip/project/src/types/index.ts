// Type definitions for the application

export interface Client {
  id: string;
  name: string;
  companyName: string;
  industry: string;
  annualRevenue: number;
  totalAssets: number;
  relationshipSince: string;
  lastContactDate: string;
  profileImage: string;
}

export interface RelationshipHealth {
  category: string;
  status: 'good' | 'warning' | 'risk';
  score: number;
  trend: 'up' | 'down' | 'stable';
  details: string;
}

export interface Opportunity {
  id: string;
  title: string;
  description: string;
  estimatedRevenue: number;
  probability: number;
  productCategory: string;
}

export interface ExecutiveSummaryPoint {
  id: string;
  title: string;
  description: string;
  priority: 'high' | 'medium' | 'low';
}

export interface TalkingPoint {
  id: string;
  category: string;
  point: string;
  relatedTo?: string;
}

export interface FollowUpTask {
  id: string;
  title: string;
  description: string;
  dueDate: string;
  priority: 'high' | 'medium' | 'low';
  completed: boolean;
  assignedTo: string;
}

export interface MeetingNote {
  id: string;
  date: string;
  type: 'call' | 'meeting' | 'email';
  summary: string;
  keyPoints: string[];
  attendees: string[];
  nextSteps?: string[];
}

export interface ServiceRequest {
  id: string;
  title: string;
  description: string;
  status: 'pending' | 'in_progress' | 'resolved' | 'blocked';
  priority: 'high' | 'medium' | 'low';
  createdAt: string;
  estimatedCompletion?: string;
  assignedTo: string;
  category: string;
  updates?: {
    date: string;
    message: string;
    author: string;
  }[];
}